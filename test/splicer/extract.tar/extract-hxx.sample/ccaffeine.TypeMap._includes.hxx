// DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._includes)
// #include <map>
// #include <utility> // need pair<T,U>
#include "dc/export/AllExport.hh"
#include "ccaffeine_CCAException.hxx"
/*
 * The implementation here is now that of the pure c++ version
 * done by ben allan, wrapped in babel.
 * It doesn't make evil assumptions about underlying
 * implementations of the sort that require reinterpret cast.
 * 
 */
// DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._includes)
