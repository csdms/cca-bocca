    // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._implementation)
    ::ccafeopq::TypeMap_shared ctm;

    template <class Scalar > sidl::array< Scalar > 
      convertToSidlArray( ::std::vector< Scalar > & val );

    template <class Scalar > ::std::vector< Scalar > 
      convertToVector( sidl::array< Scalar > & val );

    int serial;
    static int nextNum() { genSerial++; return genSerial; }
    static int genSerial;

  public:

    static ::ccaffeine::TypeMap babelWrap( ::ccafeopq::TypeMap_shared ctm_);
    
    // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._implementation)
