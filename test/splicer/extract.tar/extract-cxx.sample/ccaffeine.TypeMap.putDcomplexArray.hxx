  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putDcomplexArray)
  INSERTARRAY(sidl::dcomplex, DcomplexArray, "putDcomplexArray");
  // remove( key );
  // d_key2type[key] = gov::cca::DcomplexArray;
  // d_key2dcomplexArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putDcomplexArray)
