  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putFloatArray)
  INSERTARRAY(float, FloatArray, "putFloatArray");
  // remove( key );
  // d_key2type[key] = gov::cca::FloatArray;
  // d_key2floatArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putFloatArray)
