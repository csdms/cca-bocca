  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._ctor)
  // add construction details here
#ifdef CCAFE_AUDIT
  serial = nextNum();
  IO_dn2("ccaffeine::TypeMap_impl _ctor %d", serial);
#endif
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._ctor)
