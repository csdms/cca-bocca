  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getInt)
#define EXTRACT(TYPE, FNAME) \
  try { \
	  if (!ctm) { \
		  NILWHINE(FNAME) \
		  return dflt; \
	  } \
	  return ctm->get##TYPE(key, dflt); \
  } \
  catch ( ::ccafeopq::TypeMismatchException &e) \
  { \
    /* convert */ \
    ccaffeine::TypeMismatchException ex = ::ccaffeine::TypeMismatchException::_create(); \
    ex.initializeTypes( BabelHelper::babelType(e.getRequestedType()), \
		   BabelHelper::babelType(e.getActualType())); \
    ex.SIDL_EXCEPTION_setMessage( e.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  catch ( ::ccafeopq::Exception &e2) \
  { \
    ::ccaffeine::CCAException ex = ::ccaffeine::CCAException::_create(); \
    ex.setCCAExceptionType( \
      BabelHelper::babelExceptionType(e2.getType())); \
    ex.SIDL_EXCEPTION_setMessage( e2.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  /* not reached */ \
  return dflt 

  EXTRACT(Int, "getInt");

  // return getType( d_key2int, key, gov::cca::Int, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getInt)
