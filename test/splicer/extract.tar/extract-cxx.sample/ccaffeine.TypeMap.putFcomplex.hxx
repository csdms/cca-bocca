  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putFcomplex)
  INSERT(Fcomplex,"putFcomplex");
  // remove( key );
  // d_key2type[key] = gov::cca::Fcomplex;
  // d_key2fcomplex[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putFcomplex)
