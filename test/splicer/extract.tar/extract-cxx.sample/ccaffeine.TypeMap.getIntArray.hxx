  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getIntArray)
  // return getType( d_key2intArray, key, gov::cca::IntArray, dflt );
	

#define EXTRACTARRAY(PRIM, TYPE, FNAME) \
  if (!ctm) { \
	  NILWHINE(FNAME) \
	  return dflt; \
  } \
  ::std::vector< PRIM > vdflt = convertToVector(dflt); \
  try { \
    ::std::vector< PRIM > val = ctm->get##TYPE( key, vdflt ); \
    return convertToSidlArray( val ); \
  } \
  catch ( ::ccafeopq::TypeMismatchException &e) \
  { \
    /* convert */ \
    ccaffeine::TypeMismatchException ex; \
    ex.initializeTypes( BabelHelper::babelType(e.getRequestedType()), \
		   BabelHelper::babelType(e.getActualType())); \
    ex.SIDL_EXCEPTION_setMessage( e.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  catch ( ::ccafeopq::Exception &e2) \
  { \
    ::ccaffeine::CCAException ex = ::ccaffeine::CCAException::_create(); \
    ex.setCCAExceptionType( \
      BabelHelper::babelExceptionType(e2.getType())); \
    ex.SIDL_EXCEPTION_setMessage( e2.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  /* not reached */ \
  return dflt
  EXTRACTARRAY(int32_t, IntArray, "getIntArray");

  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getIntArray)
