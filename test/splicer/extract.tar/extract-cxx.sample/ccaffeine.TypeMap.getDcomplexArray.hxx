  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getDcomplexArray)
  EXTRACTARRAY( sidl::dcomplex, DcomplexArray, "getDcomplexArray");
  // return getType( d_key2dcomplexArray, key, gov::cca::DcomplexArray, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getDcomplexArray)
