  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getDoubleArray)
  EXTRACTARRAY(double, DoubleArray, "getDoubleArray");
  // return getType( d_key2doubleArray, key, gov::cca::DoubleArray, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getDoubleArray)
