  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._ctor2)
  // Insert-Code-Here {ccaffeine.TypeMap._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._ctor2)
