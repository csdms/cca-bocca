  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getLong)
  // return getType( d_key2long, key, gov::cca::Long, dflt );
  EXTRACT(Long, "getLong");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getLong)
