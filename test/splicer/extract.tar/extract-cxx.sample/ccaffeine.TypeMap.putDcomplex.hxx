  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putDcomplex)
  INSERT(Dcomplex,"putDcomplex");
  // remove( key );
  // d_key2type[key] = gov::cca::Dcomplex;
  // d_key2dcomplex[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putDcomplex)
