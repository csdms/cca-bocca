  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getLongArray)
  // return getType( d_key2longArray, key, gov::cca::LongArray, dflt );
  EXTRACTARRAY(SIDL_LONG_ARRAY1_PRIMITIVE, LongArray, "getLongArray"); 
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getLongArray)
