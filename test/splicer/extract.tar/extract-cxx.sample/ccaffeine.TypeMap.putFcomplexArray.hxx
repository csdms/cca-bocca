  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putFcomplexArray)
  INSERTARRAY(sidl::fcomplex, FcomplexArray, "putFcomplexArray");
  // remove( key );
  // d_key2type[key] = gov::cca::FcomplexArray;
  // d_key2fcomplexArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putFcomplexArray)
