  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getFloatArray)
  EXTRACTARRAY(float, FloatArray, "getFloatArray");
  // return getType( d_key2floatArray, key, gov::cca::FloatArray, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getFloatArray)
