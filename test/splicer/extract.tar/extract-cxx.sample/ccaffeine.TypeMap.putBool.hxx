  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putBool)
  INSERT(Bool,"putBool");
  // remove( key );
  // d_key2type[key] = gov::cca::Bool;
  // d_key2bool[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putBool)
