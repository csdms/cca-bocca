  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getAllKeys)
  // std::vector<char*> names;
  // You've gotta be kidding...
  // Babel forces me to create arrays of malloc'd strings?
  // god, this begs for a c++ IOR.
  // for (size_t = i; i < len; i++) {
  //    names[i] = strdup(onames[i].c_str());
  // }
  // looks like this was fixed sometime recently.
  size_t len;
  ::std::vector< ::std::string > onames = 
	  ctm->getAllKeys( BabelHelper::opaqueType(t));
  len = onames.size();
  sidl::array<std::string> myarray = sidl::array<std::string>::create1d( onames.size() );
  size_t i=0;
  for( ; i < len ; i++) {
#ifdef HAVE_BABEL_PATCH_0_7_0
    myarray.set( onames[i], i );
#else
    /* 074 and later array api */
    myarray.set( i , onames[i] );
#endif
  }
  return myarray;

  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getAllKeys)
