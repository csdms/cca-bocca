  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putBoolArray)
  INSERTARRAY( bool, BoolArray, "putBoolArray");
  // remove( key );
  // d_key2type[key] = gov::cca::BoolArray;
  // d_key2boolArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putBoolArray)
