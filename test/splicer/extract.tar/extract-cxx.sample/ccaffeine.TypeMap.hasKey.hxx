  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.hasKey)
  if (!ctm) {
    NILWHINE("hasKey")
    return false;
  }
  // return ( d_key2type.find(key) != d_key2type.end() );
  return ctm->hasKey(key);
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.hasKey)
