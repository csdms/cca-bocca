  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.initialize)
#ifdef CCAFE_AUDIT
  IO_dn2("TypeMap_impl init %d", serial);
#endif
  if (opaque_TypeMap_addr == 0) { 
#ifdef CCAFE_AUDIT
  IO_dn2("TypeMap_impl init %d called with null", serial);
#endif
    return;
  }
  ::ccafeopq::TypeMap_shared *otm_addr = 0;
  otm_addr = static_cast< ::ccafeopq::TypeMap_shared * >(opaque_TypeMap_addr);
  ctm = *otm_addr;
  if (!ctm) {
    NILWHINE("initialize")
    return;
  }

  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.initialize)
