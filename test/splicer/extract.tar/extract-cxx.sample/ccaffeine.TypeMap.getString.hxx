  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getString)
  // return getType( d_key2string, key, gov::cca::String, dflt );
  EXTRACT(String, "getString");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getString)
