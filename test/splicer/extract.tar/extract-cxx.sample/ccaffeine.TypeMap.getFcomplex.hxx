  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getFcomplex)
  // return getType( d_key2fcomplex, key, gov::cca::Fcomplex, dflt );
  EXTRACT(Fcomplex, "getFcomplex");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getFcomplex)
