  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putStringArray)
  INSERTARRAY( ::std::string, StringArray, "putStringArray");
  // remove( key );
  // d_key2type[key] = gov::cca::StringArray;
  // d_key2stringArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putStringArray)
