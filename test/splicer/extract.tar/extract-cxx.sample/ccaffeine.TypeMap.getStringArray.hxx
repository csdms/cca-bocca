  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getStringArray)
  EXTRACTARRAY( ::std::string, StringArray, "getStringArray");
  // return getType( d_key2stringArray, key, gov::cca::StringArray, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getStringArray)
