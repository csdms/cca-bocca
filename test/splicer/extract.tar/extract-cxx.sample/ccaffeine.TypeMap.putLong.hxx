  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putLong)
  INSERT(Long,"putLong");
  // remove( key );
  // d_key2type[key] = gov::cca::Long;
  // d_key2long[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putLong)
