  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putDoubleArray)
  INSERTARRAY(double, DoubleArray, "putDoubleArray");
  // remove( key );
  // d_key2type[key] = gov::cca::DoubleArray;
  // d_key2doubleArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putDoubleArray)
