  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getDcomplex)
  // return getType( d_key2dcomplex, key, gov::cca::Dcomplex, dflt );
  EXTRACT(Dcomplex, "getDcomplex");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getDcomplex)
