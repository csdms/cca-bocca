  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._dtor)
  // add destruction details here
#ifdef CCAFE_AUDIT
  IO_dn2("ccaffeine::TypeMap_impl _dtor %d", serial);
  serial = -serial;
#endif
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._dtor)
