  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putLongArray)
  INSERTARRAY(SIDL_LONG_ARRAY1_PRIMITIVE, LongArray, "putLongArray");
  // remove( key );
  // d_key2type[key] = gov::cca::Long;
  // d_key2longArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putLongArray)
