  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.remove)
  if (!ctm) {
    NILWHINE("remove")
    return;
  }
  ctm->remove(key);
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.remove)
