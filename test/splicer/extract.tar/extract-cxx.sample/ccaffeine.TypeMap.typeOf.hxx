  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.typeOf)
  if (!ctm) {
    NILWHINE("typeOf")
    return gov::cca::Type_NoType;
  }
  return BabelHelper::babelType(ctm->typeOf(key));
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.typeOf)
