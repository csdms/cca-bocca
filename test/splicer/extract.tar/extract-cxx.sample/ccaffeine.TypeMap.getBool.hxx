  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getBool)
  // return getType( d_key2bool, key, gov::cca::Bool, dflt );
  EXTRACT(Bool, "getBool");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getBool)
