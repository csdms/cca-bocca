  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.cloneEmpty)
  // 1. create a second ccafe TypeMap locally and a second babel wrapper locally.
  ccaffeine::TypeMap m = ccaffeine::TypeMap::_create();
  if (! ctm  ) {
#ifdef CCAFE_AUDIT
   IO_dn2("cloneEmpty called on empty wrapper %d",serial);
#endif //CCAFE_AUDIT
  }
  else {
    ::ccafeopq::TypeMap_shared newguts = ctm->cloneEmpty();
    // 2. make the new ccafe thing into  a void *.
    ::ccafeopq::TypeMap_shared * gut_addr = 0;
    void *v = 0;
    gut_addr = &newguts;
    v = static_cast<void *>(gut_addr);
    // 3. init the babel wrapper.
    m.initialize(v);
  }
  return m;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.cloneEmpty)
