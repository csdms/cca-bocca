  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putInt)
#define INSERT(TYPE, FNAME) \
  if (!ctm) { \
	  NILWHINE(FNAME) \
	  return; \
  } \
  try { \
    ctm->put##TYPE(key, value); \
  } \
  catch ( ::ccafeopq::TypeMismatchException &e) \
  { \
    /* convert */ \
    ccaffeine::TypeMismatchException ex = ::ccaffeine::TypeMismatchException::_create(); \
    ex.initializeTypes( BabelHelper::babelType(e.getRequestedType()), \
		   BabelHelper::babelType(e.getActualType())); \
    ex.SIDL_EXCEPTION_setMessage( e.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  catch ( ::ccafeopq::Exception &e2) \
  { \
    ::ccaffeine::CCAException ex = ::ccaffeine::CCAException::_create(); \
    ex.setCCAExceptionType( \
      BabelHelper::babelExceptionType(e2.getType())); \
    ex.SIDL_EXCEPTION_setMessage( e2.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  return 
  INSERT(Int,"putInt");
  // remove( key );
  // d_key2type[key] = gov::cca::Int;
  // d_key2int[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putInt)
