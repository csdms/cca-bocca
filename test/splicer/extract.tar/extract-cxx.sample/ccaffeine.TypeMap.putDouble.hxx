  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putDouble)
  INSERT(Double,"putDouble");
  // remove( key );
  // d_key2type[key] = gov::cca::Double;
  // d_key2double[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putDouble)
