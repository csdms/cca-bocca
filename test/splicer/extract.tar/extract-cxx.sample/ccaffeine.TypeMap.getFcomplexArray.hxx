  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getFcomplexArray)
  // return getType( d_key2fcomplexArray, key, gov::cca::FcomplexArray, dflt );
  EXTRACTARRAY( sidl::fcomplex, FcomplexArray, "getFcomplexArray");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getFcomplexArray)
