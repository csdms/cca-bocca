  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._load)
  // Insert-Code-Here {ccaffeine.TypeMap._load} (class initialization)
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._load)
