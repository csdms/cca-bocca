  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.cloneTypeMap)

  // 1. create a second ccafe TypeMap locally and a second babel wrapper locally.
	// If the original wrapper is hollow (huh?) send out
	// a new hollow one.
  ccaffeine::TypeMap m = ccaffeine::TypeMap::_create();

  if ( !ctm  ) {
#ifdef CCAFE_AUDIT
   IO_dn2("cloneTypeMap called on empty wrapper %d",serial);
#endif
  }
  else {
    ::ccafeopq::TypeMap_shared newguts = ctm->cloneData();
    // 2. make the new ccafe thing into  a void *.
    ::ccafeopq::TypeMap_shared * gut_addr = 0;
    void *v = 0;
    gut_addr = &newguts;
    v = static_cast<void *>(gut_addr);
    // 3. init the babel wrapper.
    m.initialize(v);
  }
  return m;


  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.cloneTypeMap)
