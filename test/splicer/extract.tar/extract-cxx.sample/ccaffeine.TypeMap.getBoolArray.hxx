  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getBoolArray)
  // return getType( d_key2boolArray, key, gov::cca::BoolArray, dflt );
  EXTRACTARRAY( bool, BoolArray, "getBoolArray");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getBoolArray)
