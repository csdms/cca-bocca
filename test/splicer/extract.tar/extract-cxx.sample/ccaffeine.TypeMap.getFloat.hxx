  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getFloat)
  EXTRACT(Float, "getFloat");
  // return getType( d_key2float, key, gov::cca::Float, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getFloat)
