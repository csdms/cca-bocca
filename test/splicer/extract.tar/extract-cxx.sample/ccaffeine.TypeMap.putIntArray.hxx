  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putIntArray)
#define INSERTARRAY(PRIM, TYPE, FNAME)  \
  if (!ctm) { \
	  NILWHINE(FNAME) \
	  return; \
  } \
  ::std::vector< PRIM > vdflt = convertToVector(value); \
  try { \
    ctm->put##TYPE( key, vdflt ); \
  } \
  catch ( ::ccafeopq::TypeMismatchException &e) \
  { \
    /* convert */ \
    ccaffeine::TypeMismatchException ex = ::ccaffeine::TypeMismatchException::_create(); \
    ex.initializeTypes( BabelHelper::babelType(e.getRequestedType()), \
		   BabelHelper::babelType(e.getActualType())); \
    ex.SIDL_EXCEPTION_setMessage( e.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  catch ( ::ccafeopq::Exception &e2) \
  { \
    ::ccaffeine::CCAException ex = ::ccaffeine::CCAException::_create(); \
    ex.setCCAExceptionType( \
      BabelHelper::babelExceptionType(e2.getType())); \
    ex.SIDL_EXCEPTION_setMessage( e2.getMessage()); \
    ex.SIDL_EXCEPTION_addToTrace( __FILE__, __LINE__, FNAME); \
    throw ex; \
  } \
  /* not reached */ \
  return 
  INSERTARRAY(int32_t, IntArray, "putIntArray");
  // remove( key );
  // d_key2type[key] = gov::cca::IntArray;
  // d_key2intArray[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putIntArray)
