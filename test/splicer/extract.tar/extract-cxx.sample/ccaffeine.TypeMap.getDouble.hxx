  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.getDouble)
  EXTRACT(Double, "getDouble");
  // return getType( d_key2double, key, gov::cca::Double, dflt );
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.getDouble)
