  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putString)
  INSERT(String,"putString");
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putString)
