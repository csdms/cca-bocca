  // DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap.putFloat)
  INSERT(Float,"putFloat");
  // remove( key );
  // d_key2type[key] = gov::cca::Float;
  // d_key2float[key] = value;
  // DO-NOT-DELETE splicer.end(ccaffeine.TypeMap.putFloat)
