// DO-NOT-DELETE splicer.begin(ccaffeine.TypeMap._includes)
#include <vector>
#include <algorithm>

#include "babel_compat.hh"
#include "ccaffeine_TypeMismatchException.hxx"
#include "dc/babel.new/ccafe-bind/BabelHelper.hh"

template<class InputIterator, class OutputIterator>
OutputIterator copy_key( InputIterator first1, InputIterator last1,
			 OutputIterator first2);

int ccaffeine::TypeMap_impl::genSerial = 0;

#ifdef CCAFE_AUDIT
#define NILWHINE(FNAME) \
	IO_dn2(" " FNAME " called with null ctm. %d ",serial);
#else
#define NILWHINE(FNAME)
#endif


// DO-NOT-DELETE splicer.end(ccaffeine.TypeMap._includes)
